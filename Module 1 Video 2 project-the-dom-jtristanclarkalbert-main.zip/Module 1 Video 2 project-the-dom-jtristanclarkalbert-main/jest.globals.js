const { quotes, adverbs, nouns, verbs, people } = require('./frontend/data')

globalThis.quotes = quotes
globalThis.adverbs = adverbs
globalThis.nouns = nouns
globalThis.verbs = verbs
globalThis.people = people
